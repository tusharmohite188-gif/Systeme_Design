from __future__ import annotations

import json
import shutil
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from fastapi import BackgroundTasks, FastAPI, File, HTTPException, UploadFile, status
from pydantic import BaseModel

APP_DIR = Path(__file__).resolve().parent
DATA_DIR = APP_DIR.parent / "data"
AUDIO_DIR = DATA_DIR / "audio"
RESULTS_DIR = DATA_DIR / "results"
for directory in (AUDIO_DIR, RESULTS_DIR):
    directory.mkdir(parents=True, exist_ok=True)

MAX_FILE_BYTES = 100 * 1024 * 1024
ALLOWED_EXTENSIONS = {".wav", ".mp3", ".m4a", ".flac", ".ogg", ".webm"}

app = FastAPI(
    title="Audio Transcription API",
    description="Assignment scaffold for asynchronous audio transcription jobs.",
    version="0.1.0",
)


class Segment(BaseModel):
    start: float
    end: float
    text: str


class JobRecord(BaseModel):
    job_id: str
    status: str
    filename: str
    created_at: str
    updated_at: str
    attempts: int = 0
    error: str | None = None
    segments: list[Segment] | None = None


# Demo-only storage. Replace with PostgreSQL in production.
JOBS: dict[str, JobRecord] = {}


def now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def persist_job(job: JobRecord) -> None:
    JOBS[job.job_id] = job
    (RESULTS_DIR / f"{job.job_id}.json").write_text(
        job.model_dump_json(indent=2), encoding="utf-8"
    )


def transcribe_audio(audio_path: Path) -> list[Segment]:
    """Replace this stub with faster-whisper or a speech-to-text provider.

    The real implementation should return one Segment per recognized speech
    segment, with timestamps relative to the beginning of the audio.
    """
    return [
        Segment(
            start=0.0,
            end=1.0,
            text=f"Demo transcript for {audio_path.name}. Connect a real speech-to-text engine.",
        )
    ]


def process_job(job_id: str) -> None:
    job = JOBS.get(job_id)
    if job is None:
        return

    job.status = "processing"
    job.updated_at = now_iso()
    job.attempts += 1
    persist_job(job)

    try:
        audio_path = AUDIO_DIR / f"{job_id}{Path(job.filename).suffix.lower()}"
        segments = transcribe_audio(audio_path)
        job.status = "completed"
        job.segments = segments
        job.error = None
    except Exception as exc:  # In production, classify retryable vs permanent errors.
        job.status = "failed"
        job.error = str(exc)[:500]
    finally:
        job.updated_at = now_iso()
        persist_job(job)


@app.get("/health")
def health() -> dict[str, str]:
    return {"status": "ok"}


@app.post("/transcriptions", status_code=status.HTTP_202_ACCEPTED)
async def create_transcription(
    background_tasks: BackgroundTasks,
    file: UploadFile = File(...),
) -> dict[str, str]:
    suffix = Path(file.filename or "").suffix.lower()
    if suffix not in ALLOWED_EXTENSIONS:
        raise HTTPException(
            status_code=415,
            detail=f"Unsupported audio extension. Allowed: {', '.join(sorted(ALLOWED_EXTENSIONS))}",
        )

    job_id = str(uuid.uuid4())
    destination = AUDIO_DIR / f"{job_id}{suffix}"
    size = 0

    try:
        with destination.open("wb") as output:
            while chunk := await file.read(1024 * 1024):
                size += len(chunk)
                if size > MAX_FILE_BYTES:
                    output.close()
                    destination.unlink(missing_ok=True)
                    raise HTTPException(status_code=413, detail="Audio file exceeds 100 MB limit.")
                output.write(chunk)
    finally:
        await file.close()

    job = JobRecord(
        job_id=job_id,
        status="queued",
        filename=file.filename or f"upload{suffix}",
        created_at=now_iso(),
        updated_at=now_iso(),
    )
    persist_job(job)
    background_tasks.add_task(process_job, job_id)
    return {"job_id": job_id, "status": "queued", "status_url": f"/transcriptions/{job_id}"}


@app.get("/transcriptions/{job_id}")
def get_transcription(job_id: str) -> dict[str, Any]:
    job = JOBS.get(job_id)
    if job is None:
        raise HTTPException(status_code=404, detail="Transcription job not found.")
    return job.model_dump(mode="json")


@app.get("/transcriptions/{job_id}/transcript")
def get_transcript(job_id: str) -> dict[str, Any]:
    job = JOBS.get(job_id)
    if job is None:
        raise HTTPException(status_code=404, detail="Transcription job not found.")
    if job.status != "completed":
        raise HTTPException(
            status_code=409,
            detail=f"Transcript is not ready. Current status: {job.status}",
        )
    return {
        "job_id": job.job_id,
        "status": job.status,
        "segments": [segment.model_dump() for segment in (job.segments or [])],
    }


@app.post("/transcriptions/{job_id}/retry", status_code=status.HTTP_202_ACCEPTED)
def retry_transcription(job_id: str, background_tasks: BackgroundTasks) -> dict[str, str]:
    job = JOBS.get(job_id)
    if job is None:
        raise HTTPException(status_code=404, detail="Transcription job not found.")
    if job.status != "failed":
        raise HTTPException(status_code=409, detail="Only failed jobs can be retried.")
    job.status = "queued"
    job.error = None
    job.updated_at = now_iso()
    persist_job(job)
    background_tasks.add_task(process_job, job_id)
    return {"job_id": job_id, "status": "queued"}


@app.delete("/transcriptions/{job_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_transcription(job_id: str) -> None:
    job = JOBS.pop(job_id, None)
    if job is None:
        raise HTTPException(status_code=404, detail="Transcription job not found.")
    suffix = Path(job.filename).suffix.lower()
    (AUDIO_DIR / f"{job_id}{suffix}").unlink(missing_ok=True)
    (RESULTS_DIR / f"{job_id}.json").unlink(missing_ok=True)
